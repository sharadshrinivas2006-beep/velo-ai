import React, { useEffect, useState } from 'react';
import { Lock, Unlock, Database, Trash2, Download, LogOut, AlertTriangle } from 'lucide-react';
import { UserCampaign, SafetyHistoryRecord } from '../../types';
import {
  loadUserCampaigns,
  saveUserCampaigns,
  saveDataSourcePreference,
  SAMPLE_STARTER_CAMPAIGNS,
} from '../../utils/analyticsCalculations';
import {
  loadSafetyHistory,
  saveSafetyHistory,
  clearSafetyHistory,
  saveSafetyHistorySource,
  SAMPLE_SAFETY_HISTORY,
} from '../../utils/safetyAuditor';

const ADMIN_PASSWORD = 'admin123';
const UNLOCK_KEY = 'velofin_admin_unlocked';

export const DataManagementTab: React.FC = () => {
  const [unlocked, setUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(UNLOCK_KEY) === '1';
    } catch {
      return false;
    }
  });
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [campaigns, setCampaigns] = useState<UserCampaign[]>([]);
  const [history, setHistory] = useState<SafetyHistoryRecord[]>([]);
  const [notice, setNotice] = useState<string | null>(null);

  const refresh = () => {
    setCampaigns(loadUserCampaigns());
    setHistory(loadSafetyHistory());
  };

  useEffect(() => {
    if (unlocked) refresh();
  }, [unlocked]);

  const showNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 3500);
  };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setUnlocked(true);
      setError('');
      setPassword('');
      try {
        sessionStorage.setItem(UNLOCK_KEY, '1');
      } catch {}
    } else {
      setError('Incorrect password.');
    }
  };

  const handleLock = () => {
    setUnlocked(false);
    try {
      sessionStorage.removeItem(UNLOCK_KEY);
    } catch {}
  };

  // ---- Campaign actions ----
  const loadSampleCampaigns = () => {
    const existingIds = new Set(campaigns.map((c) => c.id));
    const toAdd = SAMPLE_STARTER_CAMPAIGNS.filter((c) => !existingIds.has(c.id));
    const updated = [...toAdd, ...campaigns];
    saveUserCampaigns(updated);
    saveDataSourcePreference('user');
    setCampaigns(updated);
    showNotice(`Loaded ${toAdd.length} sample campaign(s)`);
  };

  const removeCampaign = (id: string, name: string) => {
    if (!window.confirm(`Remove campaign "${name}"?`)) return;
    const updated = campaigns.filter((c) => c.id !== id);
    saveUserCampaigns(updated);
    setCampaigns(updated);
    showNotice(`Removed "${name}"`);
  };

  const clearCampaigns = () => {
    if (!window.confirm('Clear ALL campaign data? This cannot be undone.')) return;
    saveUserCampaigns([]);
    setCampaigns([]);
    showNotice('Cleared all campaign data');
  };

  // ---- Safety history actions ----
  const loadSampleHistory = () => {
    const existingIds = new Set(history.map((h) => h.id));
    const toAdd = SAMPLE_SAFETY_HISTORY.filter((h) => !existingIds.has(h.id));
    const updated = [...history, ...toAdd].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    saveSafetyHistory(updated);
    saveSafetyHistorySource('user');
    setHistory(updated);
    showNotice(`Loaded ${toAdd.length} sample audit record(s)`);
  };

  const removeHistoryRecord = (id: string) => {
    if (!window.confirm('Remove this audit record?')) return;
    const updated = history.filter((h) => h.id !== id);
    saveSafetyHistory(updated);
    setHistory(updated);
    showNotice('Removed audit record');
  };

  const clearHistory = () => {
    if (!window.confirm('Clear ALL safety audit history? This cannot be undone.')) return;
    clearSafetyHistory();
    setHistory([]);
    showNotice('Cleared all safety audit history');
  };

  const clearEverything = () => {
    if (!window.confirm('Clear ALL data (campaigns and safety history)? This cannot be undone.')) return;
    saveUserCampaigns([]);
    clearSafetyHistory();
    setCampaigns([]);
    setHistory([]);
    showNotice('Cleared all data');
  };

  const loadEverything = () => {
    loadSampleCampaigns();
    loadSampleHistory();
  };

  // ---- Locked view ----
  if (!unlocked) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <form
          onSubmit={handleUnlock}
          className="bg-white border border-[#D8E2EA] rounded-lg p-6 shadow-sm space-y-4"
        >
          <div className="flex items-center gap-2 text-[#202938]">
            <Lock className="w-4 h-4 text-[#426A8C]" />
            <h2 className="text-base font-semibold">Admin access required</h2>
          </div>
          <p className="text-xs text-[#667085]">
            Enter the admin password to manage application data.
          </p>
          <input
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setError('');
            }}
            placeholder="Password"
            autoFocus
            className="w-full px-3 py-2 text-sm border border-[#D8E2EA] rounded-md focus:outline-none focus:ring-2 focus:ring-[#426A8C]/30"
          />
          {error && <p className="text-xs text-red-600">{error}</p>}
          <button
            type="submit"
            className="w-full px-3 py-2 rounded-md text-sm font-medium bg-[#426A8C] text-white hover:bg-[#365a78] transition-colors"
          >
            Unlock
          </button>
        </form>
      </div>
    );
  }

  const btnBase =
    'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border transition-colors';
  const btnNeutral = `${btnBase} border-[#D8E2EA] text-[#426A8C] bg-white hover:bg-[#F3F7FA]`;
  const btnDanger = `${btnBase} border-red-200 text-red-600 bg-white hover:bg-red-50`;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Unlock className="w-4 h-4 text-[#426A8C]" />
          <h1 className="text-lg font-semibold text-[#202938]">Data Management</h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={loadEverything} className={btnNeutral}>
            <Download className="w-3.5 h-3.5" /> Load all sample data
          </button>
          <button onClick={clearEverything} className={btnDanger}>
            <Trash2 className="w-3.5 h-3.5" /> Clear all data
          </button>
          <button onClick={handleLock} className={btnNeutral}>
            <LogOut className="w-3.5 h-3.5" /> Lock
          </button>
        </div>
      </div>

      {notice && (
        <div className="text-xs bg-[#EAF0F5] border border-[#D8E2EA] text-[#426A8C] px-3 py-2 rounded-md">
          {notice}
        </div>
      )}

      {/* Campaigns */}
      <section className="bg-white border border-[#D8E2EA] rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-[#D8E2EA]">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#667085]" />
            <h2 className="text-sm font-semibold text-[#202938]">
              Campaigns <span className="text-[#667085] font-normal">({campaigns.length})</span>
            </h2>
          </div>
          <div className="flex gap-2">
            <button onClick={loadSampleCampaigns} className={btnNeutral}>
              <Download className="w-3.5 h-3.5" /> Load sample
            </button>
            <button onClick={clearCampaigns} disabled={!campaigns.length} className={`${btnDanger} disabled:opacity-40 disabled:cursor-not-allowed`}>
              <Trash2 className="w-3.5 h-3.5" /> Clear all
            </button>
          </div>
        </div>
        {campaigns.length === 0 ? (
          <p className="px-4 py-6 text-xs text-[#667085]">No campaign data stored.</p>
        ) : (
          <ul className="divide-y divide-[#EAF0F5]">
            {campaigns.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-[#202938] truncate">{c.name}</div>
                  <div className="text-[11px] text-[#667085]">
                    {c.channel} · {c.date}
                    {c.source ? ` · ${c.source}` : ''}
                  </div>
                </div>
                <button onClick={() => removeCampaign(c.id, c.name)} className={btnDanger}>
                  <Trash2 className="w-3.5 h-3.5" /> Remove
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Safety history */}
      <section className="bg-white border border-[#D8E2EA] rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-[#D8E2EA]">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#667085]" />
            <h2 className="text-sm font-semibold text-[#202938]">
              Safety audit history <span className="text-[#667085] font-normal">({history.length})</span>
            </h2>
          </div>
          <div className="flex gap-2">
            <button onClick={loadSampleHistory} className={btnNeutral}>
              <Download className="w-3.5 h-3.5" /> Load sample
            </button>
            <button onClick={clearHistory} disabled={!history.length} className={`${btnDanger} disabled:opacity-40 disabled:cursor-not-allowed`}>
              <Trash2 className="w-3.5 h-3.5" /> Clear all
            </button>
          </div>
        </div>
        {history.length === 0 ? (
          <p className="px-4 py-6 text-xs text-[#667085]">No safety audit records stored.</p>
        ) : (
          <ul className="divide-y divide-[#EAF0F5]">
            {history.map((h) => (
              <li key={h.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-[#202938] truncate">
                    {h.modeLabel} · score {h.score} · {h.riskLevel}
                  </div>
                  <div className="text-[11px] text-[#667085] truncate">
                    {h.formattedDate}
                    {h.isSample ? ' · sample' : ''}
                  </div>
                </div>
                <button onClick={() => removeHistoryRecord(h.id)} className={btnDanger}>
                  <Trash2 className="w-3.5 h-3.5" /> Remove
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="flex items-start gap-1.5 text-[11px] text-[#667085]">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-px" />
        Data is stored in this browser only. The password check is client-side and is a convenience gate, not real security.
      </p>
    </div>
  );
};
